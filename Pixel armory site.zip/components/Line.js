export default function Line() {
  return (
  
    <hr class="h-px w-4/5 mx-auto border-0 bg-slate-700"></hr>

  );
}
