import fs from 'fs';
import path from 'path';

const allowedExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.mp4', '.mov'];

export default function handler(req, res) {
  const { projects } = req.query;
  const projectDir = path.join(process.cwd(), 'public/images/projects', projects);

  if (!fs.existsSync(projectDir)) {
    return res.status(404).json({ error: 'Project not found' });
  }

  const images = fs.readdirSync(projectDir).filter(file => {
    const ext = path.extname(file).toLowerCase();
    return allowedExtensions.includes(ext) && file !== '.DS_Store';
  });

  res.status(200).json({ images });
}
